<?php
    session_start();

    if (!isset($_SESSION["nama"])) {
        header("location:../UTS/loginForm.php");
        exit;
    }
?>

<html>
    <head>
        <title> HOME </title>
    </head>
    <body>
        <h1> ini adalah home </h1>
    </body>
</html>
