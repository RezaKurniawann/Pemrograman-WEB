<?php 
  session_start();

  if (isset($_SESSION["nama"])) {
    header("location: ../UTS/index.html");
    exit;
  }
?>

<html>
  <head>
    <title> Login Form </title>
  </head>
  <body>
      <div class="login">
        <form action="../UTS/Process/login.php" method="post">
          <input type="text" name="username" placeholder="Username" />
          <input type="password" name="password" placeholder="Password" />
          <input type="submit" name="Login" value="Login" />
        </form>
      </div>
      <div class="switch">
          <p>Belum punya akun?
              <a href="../UTS/registerForm.html">Register</a>
          </p>
      </div>
  </body>
</html>


